package com.jamin.aiagent.agent.model;

public enum AgentState {
/*
空闲
* */
    IDLE,


    RUNNING,


    FINISHED,


    ERROR
}

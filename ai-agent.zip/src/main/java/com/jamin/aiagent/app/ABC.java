package com.jamin.aiagent.app;

public class ABC {


    public ABC(){
        //
    }
}

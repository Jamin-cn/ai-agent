package com.jamin.aiagent.demo.invoke;

public interface Testapikey {
     String API_KEY = "sk-0aaf9956f92e49cc9d7db098cff4bb20";
}

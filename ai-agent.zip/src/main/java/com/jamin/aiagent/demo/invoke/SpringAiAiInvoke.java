package com.jamin.aiagent.demo.invoke;

//@Component
//public class SpringAiAiInvoke implements CommandLineRunner {
//
//    @Resource
//    private ChatModel dashscopeChatModel;
//
//    @Override
//    public void run(String... args) throws Exception {
//        AssistantMessage output = dashscopeChatModel.call(new Prompt("你是什么模型？具体到模型类型如qwen-plus"))
//                .getResult()
//                .getOutput();
//        System.out.println(output.getText());
//    }
//}